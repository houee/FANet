SparseEmfaBio <-
function (data, zeros, min.err=1e-03) {
    if (sum(rownames(zeros)==rownames(data))!=nrow(data)) 
        stop("Row names of constrains matrix and of the expression data don't match")
    nbf=ncol(zeros)
   data=scale(t(data))
   n = nrow(data)
   m = ncol(data)
   S = var(data)
   cdata = scale(data,center=TRUE,scale=FALSE)
   if (n>m) {
      if (nbf == 0) {
         B = NULL
         Psi = rep(1, m)
         Factors = NULL
      }
      if (nbf > 0) {
         print(paste("Fitting direct ML Factor Analysis Model with", nbf,"factors"))
         fa = factanal(data,factors=nbf,rotation="varimax")
         B = fa$loadings
         class(B) = "matrix"
         Psi = fa$uniquenesses
         sB = scale(t(B), center = FALSE, scale = sqrt(Psi))
         G = solve(diag(nbf) + sB %*% t(sB))
         sB = scale(t(B), center = FALSE, scale = Psi)
         Factors = cdata%*%t(sB)%*%t(G)
      }   
   }
   if (n<=m) {
      if (nbf == 0) {
         B = NULL
         Psi = rep(1, m)
         Factors = NULL
      }
      if (nbf > 0) {
         print(paste("Fitting EM Factor Analysis Model with", nbf,"factors"))
         eig = svd((1/sqrt((n - 1))) * t(cdata))
         evectors = eig$u[, 1:nbf]
         evalues = eig$d^2
         if (nbf > 1) 
            B = evectors[, 1:nbf] %*% diag(sqrt(evalues[1:nbf]))
         if (nbf == 1) 
            B = matrix(evectors, nrow = m, ncol = 1) * sqrt(evalues[1])
         Psi = diag(S) - apply(B^2, 1, sum)
         crit = 1
         while (crit > min.err) {
            iS = ifa(Psi,B)
            Cyz = S%*%iS%*%B
            Czz = t(B)%*%iS%*%S%*%iS%*%B+diag(nbf)-t(B)%*%iS%*%B
            Bnew = SparseMstep(Czz,Cyz,zeros)
            Psinew = diag(S)-2*diag(Bnew%*%t(Cyz))+diag(Bnew%*%Czz%*%t(Bnew))
            crit = mean((Psi - Psinew)^2) ; print(crit)
            B = Bnew
            Psi = Psinew
         }
         sB = scale(t(B), center = FALSE, scale = sqrt(Psi))
         G = solve(diag(nbf) + sB %*% t(sB))
         sB = scale(t(B), center = FALSE, scale = Psi)
         Factors = cdata%*%t(sB)%*%t(G)
      }
   }
   
 B[zeros==0] = 0
S = cov2cor(diag(Psi)+B%*%t(B))
   return(S)
}
