ifa <-
function(Psi,B) {
q = ncol(B)
Phi = rep(0,length(Psi))
Phi[abs(Psi)>1e-05] = 1/Psi[abs(Psi)>1e-05]
G = diag(q)+t(B)%*%diag(Phi)%*%B
diag(Phi) - diag(Phi)%*%B%*%solve(G)%*%t(B)%*%diag(Phi)
}
