sol0<-function(r,s,Cyz,Czz,hb,Psi,lambda) {  # return TRUE if solution is zero
nbf = ncol(hb)
hb0 = hb
hb0[r,s] = 0
resp = -2*(Cyz[r,s]/Psi[r])+2*(sum(hb0[r,]*Czz[,s])/Psi[r])+lambda
resm = -2*(Cyz[r,s]/Psi[r])+2*(sum(hb0[r,]*Czz[,s])/Psi[r])-lambda
return(sign(resp)!=sign(resm))
}