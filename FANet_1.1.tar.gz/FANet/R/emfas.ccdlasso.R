emfas.ccdlasso<-
 function(dta, nbf, lambda = 0, zeros=NULL,min.err=1e-06,max.iter=100) {
     S = cor(dta,use="complete")
   m = ncol(S)
   if (nbf == 0) {
      B = NULL
      Psi = rep(1, m)
   }
   if (nbf > 0) {
      print(paste("Fitting Factor Analysis Model with", nbf, 
            "factors"))
      eig = eigen(S,symmetric=TRUE)
      evectors = eig$vectors[, 1:nbf]
      evalues = eig$values[1:nbf]
      if (nbf > 1) 
         B = evectors[, 1:nbf] %*% diag(sqrt(evalues[1:nbf]))
      if (nbf == 1) 
         B = matrix(evectors, nrow = m, ncol = 1) * sqrt(evalues[1])
      Psi = diag(S) - apply(B^2, 1, sum)
      iter = 0
      stop = FALSE
      while (!stop) {
          iter = iter + 1
          iS = ifa(Psi,B)
          Cyz = S%*%iS%*%B
          Czz = t(B)%*%iS%*%S%*%iS%*%B+diag(nbf)-t(B)%*%iS%*%B
		
          faccd = cycliccd(S,Cyz,Czz,Psi,lambda,zeros,min.err,max.iter)
	    Bnew = faccd$B
          Psinew = faccd$Psi
          crit = mean(abs(sql(B) - sql(Bnew))) ; print(crit) ; # plot(sql(tB),sql(Bnew))
          stop = (crit<min.err)|(iter>=max.iter)
          B = Bnew
          Psi = Psinew
      }
   }
   res = list(B = B, Psi = Psi)
   return(res)
}