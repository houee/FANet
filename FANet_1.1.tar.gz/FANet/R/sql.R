sql<-function(M) {
M2 = M%*%t(M)
M2[lower.tri(M2)]
}