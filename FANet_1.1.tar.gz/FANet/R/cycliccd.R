cycliccd<-function(S,Cyz,Czz,Psi,lambda,zeros=NULL,min.err=1e-06,max.iter=100) {
   m = nrow(Cyz)
   nbf = ncol(Czz)
   if (is.null(zeros)) zeros = matrix(FALSE,nrow=m,ncol=nbf)
   hb = matrix(0,nrow=m,ncol=nbf)
   hPsi = Psi
   stop = FALSE
   iter = 0
   while (!stop) {
      iter = iter + 1   
      hB = hb
      for(r in 1:m) {
         for(s in 1:nbf) {
            if (zeros[r,s]==FALSE) upd = updb.lasso(r,s,Cyz,Czz,hb,hPsi,lambda) # print(paste("New = ",upd,"Old = ",B[r,s]))
            if (zeros[r,s]==TRUE) upd = 0
            hb[r,s] = upd
         }
      }
	hPsi = diag(S-hb%*%t(Cyz))
      stop = (mean(abs(sql(hb)-sql(hB)))<min.err)|(iter>max.iter)
   }
   return(list(Psi=hPsi,B=hb))
}
