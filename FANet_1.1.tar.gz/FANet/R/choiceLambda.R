choiceLambda<-function(dta) {
	
	bicfa = function(S=cor(dta),B,n) {
	nbf = ncol(B)
	nbpar = sum(abs(B)>1e-06)
	Psi = 1-apply(B^2,1,sum)
	faS = diag(Psi)+B%*%t(B)
	ldet = determinant(faS,log=TRUE)$modulus
	ifaS = ifa(Psi,B)
	dr = n*nbf*log(2*pi)+n*ldet+n*sum(diag(S%*%ifaS))
	bic = dr+log(n)*nbpar
	list(dr=dr,bic=bic)
	} 

 nbfmax = 10
 vlambda = seq(0.01,1,0.01)
 vbic = rep(0,length(vlambda))
 n = nrow(dta)
 for (k in 1:length(vlambda)) {
  falasso = emfas.ccdlasso(dta,nbf=nbfmax,lambda=vlambda[k],min.err=1e-01)
  vbic[k] = bicfa(S=cor(dta),falasso$B,n)$bic 
 }
 lambda = vlambda[which.min(vbic)]
 return(lambda)
}
