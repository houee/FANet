updb.lasso<-function(r,s,Cyz,Czz,hb,Psi,lambda) {   # Live function for LASSO on B
   nbf = ncol(Czz)
   m = nrow(Cyz)
   solm = (Cyz[r,s]-(lambda*Psi[r]/2)-sum(hb[r,-s]*Czz[-s,s]))/Czz[s,s]
   solp = (Cyz[r,s]+(lambda*Psi[r]/2)-sum(hb[r,-s]*Czz[-s,s]))/Czz[s,s]
   hb0 = hb
   hb0[r,s] = solp
   dfp = -2*(Cyz[r,s]/Psi[r])+2*(sum(hb0[r,]*Czz[,s])/Psi[r])+lambda*sign(solp)
   hb0[r,s] = solm
   dfm = -2*(Cyz[r,s]/Psi[r])+2*(sum(hb0[r,]*Czz[,s])/Psi[r])+lambda*sign(solm)
   if(abs(dfp)<1e-08) sol = solp
   if(abs(dfm)<1e-08) sol = solm
   if (sol0(r,s,Cyz,Czz,hb,Psi,lambda)) sol = 0
   return(sol)
}
